package com.escutia.cs478project4;

/*
* CS 478 Project 4: Multithreaded Three Men's Morris
* By: Alexis Escutia
*/

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;


public class MainActivity extends AppCompatActivity {

    private static final int START_GAME = 0;  // Message for the UI thread to start the 3MM Game
    private static final int DISPLAY_RED = 1;  // Message for the UI thread to display Red's Move
    private static final int DISPLAY_BLUE = 2;  // Message for the UI thread to display Blue's Move
    private static final int MAKE_MOVE = 3;  // Message for the Worker threads to find their next move

    private int winner = 0;  // used to store who the winner is

    // Handler for the UI thread
    Handler uiHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            Message message;
            int what = msg.what;
            int index;  // Stores the index where the player moved it's piece
            switch (what) {
                case START_GAME:
                    Log.d("UI THREAD", "Starting Game!!");
                    redHandler.post(new Runnable() {  // Sleeping red thread for 1.5 sec before making move
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1500);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                    message = redHandler.obtainMessage(MAKE_MOVE);  // Sends Message to the Red Thread to start generating a move
                    redHandler.sendMessage(message);
                    break;

                case DISPLAY_RED:
                    blueHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1500);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                    updateUI();  // Displays the move on the main board
                    index = msg.arg1;
                    Log.i("UI THREAD", "Red moved his piece to position " + (index+1) + "!");
                    if(checkWin(1)) {  // if Red wins, end the game, else notify UI thread of the move that was made
                        winner = 1;
                        gameOver();
                        Log.i("UI THREAD", "Red won the game!!!");
                    } else {
                        message = blueHandler.obtainMessage(MAKE_MOVE);
                        blueHandler.sendMessage(message);
                    }
                    break;

                case DISPLAY_BLUE:
                    redHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1500);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                    updateUI();  // Displays the move on the main board
                    index = msg.arg1;
                    Log.i("UI THREAD", "Blue moved his piece to position " + (index+1)  + "!");
                    if(checkWin(2)) {  // if Blue wins, end the game, else notify UI thread of the move that was made
                        winner = 2;
                        gameOver();
                        Log.i("UI THREAD", "Blue won the game!!!");
                    } else {
                        message = blueHandler.obtainMessage(MAKE_MOVE);
                        redHandler.sendMessage(message);
                    }
                    break;
                default:
                    break;
            }
        }
    };
    Handler redHandler;
    Handler blueHandler;

    Thread redPlayer;
    Thread bluePlayer;

    private int redCount = 0;  // Keeps track of Red's total pieces
    private int blueCount = 0;  // Keeps track of Blue's totalpieces
    private int currBlue = 0;

    private final int[] btnIds = {  // Stores the ids of the buttons in the grid layout
            R.id.b1,R.id.b2,R.id.b3,
            R.id.b4,R.id.b5,R.id.b6,
            R.id.b7,R.id.b8,R.id.b9
    };

    private final int[] gameBoard = {  // array version of the board to keep track
            0,0,0,
            0,0,0,
            0,0,0
    };

    private ArrayList<Integer> redPieces = new ArrayList<>(Arrays.asList(0,0,0));  // stores the indexes where red's pieces are at
    private ArrayList<Integer> bluePieces = new ArrayList<>(Arrays.asList(0,0,0));  // stores the indexes where blue's pieces are at
    private ArrayList<Integer> freeSpaces = new ArrayList<>(Arrays.asList(0,0,0));  // stores the indexes where the free spaces are at

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button start = findViewById(R.id.startBtn);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // void current game and start a new one
                if(redPlayer != null) {
                    uiHandler.removeCallbacksAndMessages(null);
                    redHandler.removeCallbacksAndMessages(null);
                    blueHandler.removeCallbacksAndMessages(null);
                    redHandler.getLooper().quitSafely();
                    blueHandler.getLooper().quitSafely();
                    reset();
                }

                redPlayer= new Thread(new Runnable() {
                    @SuppressLint("HandlerLeak")
                    @Override
                    public void run() {
                        Looper.prepare();
                        redHandler = new Handler(){
                            @Override
                            public void handleMessage(@NonNull Message msg) {
                                int what = msg.what;
                                Message message;
                                switch (what){
                                    case MAKE_MOVE:  // Strategy: Place pieces randomly
                                        int index;
                                        if(redCount < 3) {  // first place pieces randomly
                                            while (true) {  // loops until the returned index is free
                                                index = placePiece();
                                                if(gameBoard[index] == 0) {
                                                    gameBoard[index] = 1;
                                                    break;
                                                }
                                            }
                                            redPieces.set(redCount,index);
                                            redCount++;
                                        } else {  // select a random red piece and move its position on the board
                                            index = makeMove();
                                        }
                                        message = uiHandler.obtainMessage(DISPLAY_RED);
                                        message.arg1 = index;
                                        uiHandler.sendMessage(message);  // Messages the ui handler containing the index where the piece was moved to
                                    default:
                                        break;
                                }
                            }
                        };
                        Looper.loop();
                    }
                });
                redPlayer.start();


                bluePlayer= new Thread(new Runnable() {
                    @SuppressLint("HandlerLeak")
                    @Override
                    public void run() {
                        Looper.prepare();
                        blueHandler = new Handler(){
                            @Override
                            public void handleMessage(@NonNull Message msg) {
                                int what = msg.what;
                                Message message;
                                switch (what){
                                    case MAKE_MOVE:  // Strategy: Place piece at the first spot available
                                        int index = findFirstSpace();

                                        message = uiHandler.obtainMessage(DISPLAY_BLUE);
                                        message.arg1 = index;
                                        uiHandler.sendMessage(message);  // Messages the ui handler containing the index where the piece was moved to
                                    default:
                                        break;
                                }
                            }
                        };
                        Looper.loop();
                    }
                });
                bluePlayer.start();

                // Message the Handler to start the game
                Message message = uiHandler.obtainMessage(START_GAME);
                uiHandler.sendMessage(message);
            }
        });


    }

    // returns a random index for the pieces to be placed
    private int placePiece() {
        Random randNum = new Random();
        return randNum.nextInt(9);
    }

    // generates red's next move
    private int makeMove() {
        Random randNum = new Random();
        int piece = randNum.nextInt(3);  // select one of red's 3 available pieces
        int index;  // stores the index where the piece will move to
        int oldSpot;  // stores the index where the selected red piece is currently
        oldSpot = redPieces.get(piece);

        findFreeSpaces();
        int selectedSpot = randNum.nextInt(3);
        index = freeSpaces.get(selectedSpot);

        // move the red piece to it's new position
        int temp = gameBoard[oldSpot];
        gameBoard[oldSpot] = gameBoard[index];
        gameBoard[index] = temp;

        redPieces.set(piece, index);  // updates the piece's new location
        return index;
    }

    // clears the board and resets all values to 0
    private void reset(){
        for(int x = 0; x < 9; x++) {
            Button test = findViewById(btnIds[x]);
            test.setBackgroundColor(Color.BLACK);
            gameBoard[x] = 0;
        }

        for(int x = 0; x < 3; x++) {
            redPieces.set(x,0);
            bluePieces.set(x,0);
        }
        redCount = 0;
        blueCount = 0;
    }

    // iterates the game board array and updates the grid to display the pieces
    private void updateUI() {
        for(int x = 0; x < 9; x++) {
            Button curr = findViewById(btnIds[x]);
            if(gameBoard[x] == 1) {
                curr.setBackgroundColor(Color.RED);
            }else if(gameBoard[x] == 2) {
                curr.setBackgroundColor(Color.CYAN);
            } else {
                curr.setBackgroundColor(Color.BLACK);
            }
        }
    }

    // returns true if a player won
    private boolean checkWin(int player) {
        if(checkVertical(player)) {
            return true;
        } else if(checkHorizontal(player)){
            return true;
        } else {
            return false;
        }
    }

    // checks all columns to see if the player's pieces match, if all 3 pieces match return true, else return false
    private boolean checkVertical(int player) {
        if(gameBoard[0] == player && gameBoard[3] == player && gameBoard[6] == player) {
            return true;
        } else if(gameBoard[1] == player && gameBoard[4] == player && gameBoard[7] == player) {
            return true;
        } else if(gameBoard[2] == player && gameBoard[5] == player && gameBoard[8] == player) {
            return true;
        } else {
            return false;
        }
    }

    // checks all rows to see if the player's pieces match, if all 3 pieces match return true, else return false
    private boolean checkHorizontal(int player) {
        if(gameBoard[0] == player && gameBoard[1] == player && gameBoard[2] == player) {
            return true;
        } else if(gameBoard[3] == player && gameBoard[4] == player && gameBoard[5] == player) {
            return true;
        } else if(gameBoard[6] == player && gameBoard[7] == player && gameBoard[8] == player) {
            return true;
        } else {
            return false;
        }
    }

    // finds the index of the 3 free spaces and updates the freeSpaces array
    private void findFreeSpaces() {
        int i = 0;
        for(int x = 0; x < 9; x++) {
            if(gameBoard[x] == 0) {
                freeSpaces.set(i,x);
                i++;
            }
        }
    }

    // find the first open space where blue can place its piece
    private int findFirstSpace() {
        int temp;
        int oldSpot;
        for(int x = 0; x < 9; x++) {
            if(gameBoard[x] == 0) {
                if(blueCount < 3) {  // if all 3 pieces arent placed, set them normally, else swap the values
                    bluePieces.set(currBlue, x);
                    gameBoard[x] = 2;
                    blueCount++;
                } else {
                    oldSpot = bluePieces.get(currBlue);
                    temp = gameBoard[oldSpot];
                    gameBoard[oldSpot] = gameBoard[x];
                    gameBoard[x] = temp;
                    bluePieces.set(currBlue, x);
                }
                if(currBlue == 2) {
                    currBlue = 0;
                } else {
                    currBlue++;
                }
                return x;
            }
        }
        return -1;  // return if error
    }

    // Ends all threads and displays a toast that shows which player won
    public void gameOver() {
        uiHandler.removeCallbacksAndMessages(null);
        redHandler.removeCallbacksAndMessages(null);
        blueHandler.removeCallbacksAndMessages(null);
        redHandler.getLooper().quitSafely();
        blueHandler.getLooper().quitSafely();
        String test;
        if(winner == 1) {
            test = "Game Over: Red Wins!!";
        } else {
            test = "Game Over: Blue Wins!!";
        }
        Toast.makeText(MainActivity.this, test, Toast.LENGTH_LONG).show();

    }
}